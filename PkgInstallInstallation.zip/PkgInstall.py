#!/usr/bin/env python

import os

os.system('pkg upgrade && pkg update && pkg install x11-repo && pkg install root-repo && pkg upgrade && pkg update && pkg install vim && pkg install wget && pkg install python && pkg install python2 && pkg install python-pip && pkg install proot && pkg install git && pkg install figlet && pkg install toilet && pkg install python-tkinter && pkg install git clang python && pkg install cmake && pkg install apt && pkg install clang && pkg install zip && pkg install curl && pkg install unzip && pkg install p7zip && pkg install aria2 && pkg install tigervnc && pkg install tsu && pkg install python psutils')

os.system('pip install tqdm && pip install requests && pip install mechanize && pip install tqdm && pip install Pillow && pip install imgcat && pip install virtualenv && pip install psutil')

os.system('virtualenv env_name')
os.system('source env_name/bin/activate')
