import sys
import time
import getpass

time.sleep(2)

import time
print('WELCOME TO OUR FACILITY')
time.sleep(2)

import time
print('What you want to do? Login or Register?')

authenticated = False
while not authenticated:

    choice = input('>>>')

    if choice == 'Login':
        time.sleep(2)
        print('We are redirecting you to the LogIn Page of our Facility')
        time.sleep(2)
        
        print('Please Wait For A While')
        time.sleep(5)

        print('You are now on LogIn Page of our Facility')
        time.sleep(2)

        print('Please Login Your Registered Account')

        nameuser = ('Kyle C. Alarzar')
        ageuser = ('21')
        adduser = ('Pulong, Magtaking San Carlos City')
        username1 = ('kyle')
        password1 = ('121222')


        authenticated = False
        while not authenticated:

            a1 = input('Username: ')
            b1 = input('Password: ')

            if a1 == 'kyle' and b1 == '121222':
                print('Log In Successful')
                authenticated = True

                time.sleep(2)

                import time
                print('     ∆∆∆***Here Is Your Credentials***∆∆∆')
                print('...')
                time.sleep(4)

                print('          ***Acquiring Your Credentials***')
                print('...')
                time.sleep(4)
                
                print('          ***Setting Up Your Credentials***')
                print('...')
                time.sleep(4)
                
                print('                 YOUR CREDENTIALS')
                time.sleep(2)

                print(f'NAME: {nameuser}')
                time.sleep(2)
                print(f'AGE: {ageuser}')
                time.sleep(2)
                print(f'ADDRESS: {adduser}')
                time.sleep(2)
                print(f'USERNAME: {username1}')
                time.sleep(2)
                print(f'PASSWORD: {password1}')
                time.sleep(2)

                print('This Is The Credential of the Owner Of This Facility')
                time.sleep(2)
                print('For Any Help. Ask Our Facility Manager')
                time.sleep(2)
                sys.exit(1)
            else:
                print('Login Failed "Your Account Is Not Recognize"')
                time.sleep(2)
                print('Please LogIn Again')
    else:
        if choice == 'Register':
            time.sleep(2)
            print('WELCOME TO ACCOUNT REGISTRATION PLATFORM SYSTEM')
            time.sleep(3)
            print('REGISTER YOUR ACCOUNT FOR AUTHENTICATION')
            
            a = input('Username: ')
            b = input('Password: ')
            time.sleep(2)

            import time
            print('Registering Your Account To Our Facility')
            time.sleep(1)

            import time
            print('Please Wait For A While...')
            time.sleep(5)

            import time
            print('Account Successfully Registered')
            time.sleep(2)

            import time
            print('We are redirecting you to LogIn page of our Facility')
            authenticated = True
        else:
            print('Choice not identified... Please copy exactly the choices... Be careful with Capitalizations of letter')

time.sleep(2)

import time
print('Please Wait For A While')
time.sleep(5)

import time
print('You are now on Login Page of our Facility')
time.sleep(2)

import time
print('Please Login Your Registered Account')

nameuser = ('Kyle C. Alarzar')
ageuser = ('21')
adduser = ('Pulong, Magtaking San Carlos City')
username1 = ('kyle')
password1 = ('121222')

authenticated = False
while not authenticated:

    a1 = input('Username: ')
    b1 = input('Password: ')

    if a1 == 'kyle' and b1 == '121222':
        print('Log In Successful')
        authenticated = True

        time.sleep(2)
        
        import time
        print('         ∆∆∆***Here Is Your Credentials***∆∆∆')
        print('...')
        time.sleep(4)                                 
        print('          ***Acquiring Your Credentials***')
        print('...')
        time.sleep(4)                                 
        print('         ***Setting Up Your Credentials***')
        print('...')
        time.sleep(4)

        print('                    YOUR CREDENTIALS')
        print('...')
        time.sleep(2)

        print(f'NAME: {nameuser}')
        time.sleep(2)                                         
        print(f'AGE: {ageuser}')
        time.sleep(2)
        print(f'ADDRESS: {adduser}')                          
        time.sleep(2)
        print(f'USERNAME: {username1}')
        time.sleep(2)                                         
        print(f'PASSWORD: {password1}')
        time.sleep(4)

        print('This Is The Credentials Of The Owner Of This Facility')
        time.sleep(2)

        print('For Any Help, Ask Our Facility Manager')
        time.sleep(4)

        sys.exit(1)

    elif a1 == a and b1 == b:
        print('Login Successful')

        authenticated = True

    else:

        print('Login Failed "Your Account Is Not Recognize"')
        time.sleep(2)
        print('Please Login Again!')

time.sleep(2)

import time
print('We redirecting you to Facility Page...')
time.sleep(2)

import time
print('You Are Now On Facility Page')
time.sleep(2)

import time
print('Please provide your self identity/information to saved in our Facilty Files for your Identification. Thank You for Cooperation...')
time.sleep(2)

import time
print('Proccessing...')
time.sleep(5)

name = input('What is your Name: ')

time.sleep(2)

print(f'Hello {name}')
time.sleep(2)

authenticated = False
while not authenticated:
    
    age = input("How old are you? ")
    if age.isnumeric():
        age = int(age)
        if age >= 18:
            print("Your age is Authorized.")
            authenticated = True
        elif age <= 17:
            print("Your age is Unauthorized")
    else:
        print("Invalid input. Please input your proper Age")


time.sleep(2)

import time
print('Where Do You Lived In?')
address = input('>>>')
time.sleep(2)

print('What Is Your Gender? Male or Female?')

authenticated = False
while not authenticated:

    gender = input('>>>')
    if gender == 'Male':
        authenticated = True
    elif gender == 'Female':
        authenticated = True
    else:
        print('Improper Typing "Copy Exact The Choices, Be Carefull With Capitalization"')

time.sleep(2)

import time
print('         ***Finalizing Your Identity...')
time.sleep(2)

import time
print('Please Wait For A While')
time.sleep(5)

import time
print('***Your Credentials/Information Successfully Analyze And Stored...')
time.sleep(2)

import time
print('       ∆∆∆***HERE IS YOUR CREDENTIALS***∆∆∆')
print('...')
time.sleep(4)

import time
print('          ***Acquiring Your Credentials***')
print('...')
time.sleep(4)

import time
print('         ***Setting Up Your Credentials***')
print('...')
time.sleep(4)

import time
print('                 YOUR CREDENTIALS')
print('...')
time.sleep(2)

print(f'NAME: {name}')
time.sleep(2)
print(f'AGE: {age}')
time.sleep(2)
print(f'ADDRESS: {address}')
time.sleep(2)
print(f'GENDER: {gender}')
time.sleep(2)
print(f'USERNAME: {a1}')
time.sleep(2)
print(f'PASSWORD: {b1}')
time.sleep(2)
print('...')
time.sleep(2)

import time
print('If your credentials we show is Correct!')
print('Type Continue')
print('If your credentials we show have a Mistake!')
print('Type Return')

authenticated = False
while not authenticated:

    d = input('>>>')

    if d == 'Continue':
        print('            ***Continuing***')
        print('...')
        authenticated = True
    elif d == 'Return':
        print('            ***Returning***')
        print('...')
        authenticated = True
        time.sleep(4)

        print('     ***SetUp Again Your Credentials***')
        print('...')
        time.sleep(4)

        print('Please Put Your Credentials Carefully, Be Careful With Capitalization "Its Priority" Check your Credentials first before pressing Enter')
        time.sleep(4)

        print('  ***Preparing The Identity/Information Analysis***')
        time.sleep(2)

        print('Analysis Program Starting')
        time.sleep(4)

        name1 = input('What is your name?: ')
        time.sleep(2)

        print(f'Hello {name1}')
        time.sleep(2)

        authenticated = False
        while not authenticated:

            age1 = input("How old are you? ")
            if age1.isnumeric():
                age1 = int(age1)
                if age1 >= 18:
                    print("Your age is Authorized.")
                    authenticated = True
                elif age1 <= 17:
                    print("Your age is Unauthorized")
            else:
                print("Invalid input. Please input your proper Age")

        time.sleep(2)

        print('Where Do You Lived In?')
        address1 = input('>>>')
        time.sleep(2)

        print('What Is Your Gender? Male or Female?')

        authenticated = False
        while not authenticated:

            gender1 = input('>>>')

            if gender1 == 'Male':
                authenticated = True
            elif gender1 == 'Female':
                authenticated = True
            else:
                print('Improper Typing "Copy Exact The Choices, Be Carefull With Capitalization"')

        time.sleep(2)

        import time
        print('     ***Finalizing Your Identity...')
        time.sleep(2)

        import time
        print('Please Wait For A While')
        time.sleep(5)

        import time
        print('***Your Credentials/Information Successfully Analyze And Stored...')
        time.sleep(2)

        import time
        print('       ∆∆∆***HERE IS YOUR CREDENTIALS***∆∆∆')
        print('...')
        time.sleep(4)

        import time
        print('          ***Acquiring Your Credentials***')
        print('...')
        time.sleep(4)

        import time
        print('         ***Setting Up Your Credentials***')
        print('...')
        time.sleep(4)

        import time
        print('               YOUR FINAL CREDENTIALS')
        print('...')
        time.sleep(2)

        print(f'NAME: {name1}')
        time.sleep(2)
        print(f'AGE: {age1}')
        time.sleep(2)
        print(f'ADDRESS: {address1}')
        time.sleep(2)
        print(f'GENDER: {gender1}')
        time.sleep(2)
        print(f'USERNAME: {a1}')
        time.sleep(2)
        print(f'PASSWORD: {b1}')
        time.sleep(2)
        print('...')
        time.sleep(5)
    else:
        print('Invalid Input, "Please Copy The Exact Choices, Be Carefull With Capitalizations')

time.sleep(2)

print('Administrator: What Position In Our Company You Applying For?')
j = input('>>>')
time.sleep(2)

print(f'Administrator: Your Applying For {j}')
print('...')
time.sleep(2)

print('         ***Searching For Available Staff Slot...')
time.sleep(5)

print('Administrator: For The Mean Time We Have Full/Occupied Of Staff')
print('...')
time.sleep(2)

print('Administrator: Please Wait For Our Recruiter Call')
time.sleep(2)

print('Administrator: It will Tell You Wether You Come Here')
time.sleep(2)

print('Administrator: Thanks For Supporting Our Facility')
print('...')
time.sleep(2)

print(f'Administrator: See You Soon When We Have Vacant Slot For Your Application Form {j}')
time.sleep(2)

print('Administrator: Thanks For Your Patience Our Dear Employees')
time.sleep(5)

sys.exit(1)
